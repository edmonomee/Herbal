import { createApp } from 'vue'
import App from './App.vue'

import 'vuetify/styles'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

import { importHerbs } from './db/indexeddb.js'
import herbs from './data/herbs.json'

const vuetify = createVuetify({
  components,
  directives,
  theme: {
    defaultTheme: 'light',
    themes: {
      light: {
        colors: {
          primary: '#4CAF50',
          secondary: '#FFF8E1'
        }
      }
    }
  }
})

async function initDataOnce() {
  if (!localStorage.getItem('herbs_imported')) {
    await importHerbs(herbs)
    localStorage.setItem('herbs_imported', 'yes')
  }
}

initDataOnce().then(() => {
  createApp(App).use(vuetify).mount('#app')
})
<template>
  <div>
    <v-text-field
      v-model="search"
      label="搜尋中藥材"
      prepend-inner-icon="mdi-magnify"
      density="compact"
      hide-details
      clearable
    />
    <v-list>
      <v-list-item
        v-for="item in filtered"
        :key="item.中文名"
        @click="$emit('select', item)"
      >
        <v-list-item-title>{{ item.中文名 }}</v-list-item-title>
      </v-list-item>
    </v-list>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { getAllHerbs } from '../db/indexeddb.js'

const search = ref('')
const herbs = ref([])

onMounted(async () => {
  herbs.value = await getAllHerbs()
})

const filtered = computed(() => {
  if (!search.value) return herbs.value
  return herbs.value.filter(h =>
    h.中文名.includes(search.value) ||
    h.英文名?.some?.(e => e?.toLowerCase().includes(search.value.toLowerCase()))
  )
})
</script>
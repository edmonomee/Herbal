<template>
  <v-card v-if="item" class="pa-4" flat>
    <v-card-title class="text-h6">{{ item.中文名 }}</v-card-title>
    <v-card-subtitle v-if="item.英文名?.length">
      <div v-for="e in item.英文名" :key="e" v-if="e">{{ e }}</div>
    </v-card-subtitle>
    <v-card-text>
      <p>{{ item.說明 }}</p>
      <div v-if="item.標準網址">
        <v-btn
          color="primary"
          variant="tonal"
          :href="item.標準網址"
          target="_blank"
          class="mt-2"
        >
          查看標準文件
        </v-btn>
      </div>
    </v-card-text>
  </v-card>
  <v-card v-else class="pa-4" flat>
    <v-card-text>請從左側選擇一項中藥材</v-card-text>
  </v-card>
</template>

<script setup>
defineProps({ item: Object })
</script>
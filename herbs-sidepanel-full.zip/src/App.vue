<template>
  <v-app>
    <v-main>
      <v-container fluid>
        <v-row>
          <v-col cols="4">
            <ProductList @select="selected = $event" />
          </v-col>
          <v-col cols="8">
            <ProductDetail :item="selected" />
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>

<script setup>
import ProductList from './components/ProductList.vue'
import ProductDetail from './components/ProductDetail.vue'
import { ref } from 'vue'

const selected = ref(null)
</script>
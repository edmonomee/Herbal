const DB_NAME = 'herb-database'
const DB_VERSION = 1
const STORE_NAME = 'herbs'

export function initDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = e => {
      const db = e.target.result
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: '中文名' })
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

export async function importHerbs(jsonArray) {
  const db = await initDB()
  const tx = db.transaction(STORE_NAME, 'readwrite')
  const store = tx.objectStore(STORE_NAME)
  for (const item of jsonArray) {
    const merged = {
      中文名: item.中文名,
      英文名: [item.英文名1 || item.英文名 || '', item.英文名2 || '', item.英文名3 || ''],
      說明: item.說明,
      標準網址: item['中藥材標準'] || item['香港中藥材標準'] || ''
    }
    store.put(merged)
  }
  return tx.complete
}

export async function getAllHerbs() {
  const db = await initDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly')
    const store = tx.objectStore(STORE_NAME)
    const request = store.getAll()
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}